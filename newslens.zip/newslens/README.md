# NewsLens - News Article Classifier

Client-side text-mining app that predicts a news article's category
(Politics, Sports, Technology, Business, Entertainment, Health, Science, World).

## Run
Open `index.html` in a browser, or serve the folder:

    python3 -m http.server 8000   # then visit http://localhost:8000

No build step and no backend.

## How it works (src/app.js)
- Pipeline: lowercase -> tokenise -> stop-word removal -> light stemming
- Features: sublinear TF-IDF, L2-normalised
- Model: multinomial logistic regression (softmax, L2 regularisation),
  trained by gradient descent in the browser on a small built-in corpus (`D`)
- Evidence terms: TF-IDF value x learned weight margin vs. other classes
- Prediction history stored in localStorage
- Import: .txt/.md/.csv/.json/.html, .docx (mammoth.js), .pdf (pdf.js)

## Notes
- Mammoth and pdf.js load from cdnjs, so an internet connection is needed for Word/PDF import.
- Image import relies on the Claude artifact runtime (`claude.use("sample")`);
  outside claude.ai it shows "not available". To add local OCR, integrate Tesseract.js.
- For real accuracy, replace the corpus `D` with a large labelled dataset (e.g. BBC News, AG News).
