const D={
"Politics":["government election parliament minister president senate congress vote voters campaign party policy law bill legislation democrat republican prime minister coalition opposition diplomat treaty sanctions mayor governor","lawmakers debated the new bill as the president and senate leaders negotiated policy before the election","the prime minister faced a vote in parliament while the opposition party criticised government reforms and taxes","candidates campaigned across the country as voters prepared for the national election and polls showed a tight race"],
"Sports":["football soccer basketball tennis cricket baseball match game team player coach season league championship tournament goal score win defeat stadium olympic medal athlete final","the striker scored twice as the team won the match and moved top of the league table","the coach praised his players after the championship final victory at the packed stadium","the tennis champion beat her rival in straight sets to reach the tournament final and defend the title"],
"Technology":["software hardware app startup artificial intelligence AI chip processor smartphone cloud data cyber security internet robot algorithm computing device launch update developers code platform","the company unveiled a new smartphone with a faster processor and improved artificial intelligence features","developers released a software update to fix a security flaw as the startup expanded its cloud platform","researchers trained a machine learning model on large data to power new apps and robots"],
"Business":["market stock shares economy inflation bank investors profit revenue earnings company merger acquisition trade tariff interest rates growth sales finance dollar oil prices ceo quarterly","shares rose after the company reported strong quarterly earnings and revenue growth beating investor expectations","the central bank raised interest rates to fight inflation as markets and the dollar reacted","the merger creates a giant firm as the ceo promised higher sales profit and economic growth"],
"Entertainment":["movie film actor actress director album singer concert music festival celebrity hollywood award oscar series streaming box office premiere star show theatre band song","the actor won best film at the awards ceremony after the director's movie topped the box office","the singer announced a world concert tour and released a new album with hit songs","the streaming series premiere drew millions of viewers while celebrity guests walked the red carpet"],
"Health":["health doctor hospital patients disease virus vaccine cancer medicine treatment drug clinical symptoms diet mental surgery nurse pandemic infection cure care obesity","doctors said the new vaccine reduced infection and hospital admissions among patients during the outbreak","a clinical trial found the drug improved cancer treatment and survival of patients","health officials urged people to improve diet and exercise to lower risk of heart disease and obesity"],
"Science":["scientists research study space nasa planet climate earth species universe discovery physics biology astronomy telescope experiment fossil energy ocean laboratory mars satellite","astronomers using a telescope discovered a distant planet orbiting a star in the galaxy","scientists published a study showing climate change is warming the ocean and threatening species","the nasa mission launched a satellite and rocket to study mars and the solar system"],
"World":["war conflict ceasefire refugees united nations border troops attack earthquake flood disaster crisis humanitarian international summit embassy military missile protest aid foreign","the united nations called for a ceasefire as thousands of refugees fled the conflict across the border","a powerful earthquake struck the region killing dozens as rescue teams and humanitarian aid arrived","world leaders met at an international summit to discuss the war, military threats and foreign aid"]};
const EMO={Politics:"🏛️",Sports:"⚽",Technology:"💻",Business:"📈",Entertainment:"🎬",Health:"🩺",Science:"🔬",World:"🌍"};
const SAMPLES={"⚽ Sports":"Manchester City beat Arsenal 2-1 in a thrilling league match as the striker scored a late goal. The coach praised his players after the victory at the stadium, moving the team top of the table.",
"💻 Tech":"The company unveiled a new smartphone powered by an advanced AI chip. Developers say the software update improves cloud security and brings faster apps to millions of devices.",
"📈 Business":"Shares jumped after the bank reported record quarterly profit and revenue. Investors expect the central bank to cut interest rates as inflation cools and the economy grows.",
"🩺 Health":"A new vaccine cut hospital admissions by half in a large clinical trial, doctors reported. Patients showed fewer symptoms and the treatment may help fight the virus.",
"🏛️ Politics":"The senate passed the bill after a heated vote, as the president urged lawmakers to back the policy ahead of next month's election campaign."};
const STOP=new Set("the and for with was were are been its this that from has have had will would said says not but they their his her after over about into than more also new can may one two who which what when where while very just our out all any".split(" "));
const stem=w=>w.length>4?w.replace(/(ations|ation|ings|ing|ed|es|s|ly)$/,""):w;
const tok=t=>(t.toLowerCase().match(/[a-z]+/g)||[]).filter(w=>w.length>2);
const clean=t=>tok(t).filter(w=>!STOP.has(w));
const cats=Object.keys(D),V=new Map(),ex=[];
for(const c of cats){const parts=[];for(const d of D[c]){parts.push(d);const w=d.split(/\s+/);if(w.length>14)for(let i=0;i<w.length;i+=8)parts.push(w.slice(i,i+10).join(" "))}for(const d of parts){const t=clean(d).map(stem);if(t.length>2)ex.push({y:cats.indexOf(c),t})}}
const docs=ex.length;
ex.forEach(e=>new Set(e.t).forEach(w=>{if(!V.has(w))V.set(w,{i:V.size,df:0});V.get(w).df++}));
const idf=new Float64Array(V.size);V.forEach(v=>idf[v.i]=Math.log((1+docs)/(1+v.df))+1);
function vec(t){const f={};t.forEach(w=>{if(V.has(w)){const i=V.get(w).i;f[i]=(f[i]||0)+1}});let n=0;for(const i in f){f[i]=(1+Math.log(f[i]))*idf[i];n+=f[i]*f[i]}n=Math.sqrt(n)||1;for(const i in f)f[i]/=n;return f}
const K=cats.length,W=cats.map(()=>new Float64Array(V.size)),B=new Float64Array(K);
function probs(f){const s=cats.map((_,k)=>{let z=B[k];for(const i in f)z+=W[k][i]*f[i];return z});const m=Math.max(...s),e=s.map(x=>Math.exp(x-m)),z=e.reduce((a,b)=>a+b,0);return e.map(x=>x/z)}
const X=ex.map(e=>vec(e.t));
for(let ep=0;ep<300;ep++)X.forEach((f,n)=>{const p=probs(f);for(let k=0;k<K;k++){const g=p[k]-(ex[n].y===k?1:0);for(const i in f)W[k][i]-=(g*f[i]+0.0005*W[k][i]);B[k]-=g}});
const acc=ex.filter((e,n)=>{const p=probs(X[n]);return p.indexOf(Math.max(...p))===e.y}).length/docs;
function classify(text){
 const raw=tok(text),kept=raw.filter(w=>!STOP.has(w)),st=kept.map(stem);
 const known=st.filter(w=>V.has(w));
 const f=vec(st),pr=probs(f);
 const p=cats.map((c,k)=>({c,p:pr[k]})).sort((a,b)=>b.p-a.p);
 const top=cats.indexOf(p[0].c),ev={};
 known.forEach(w=>{const i=V.get(w).i;ev[w]=(f[i]||0)*(W[top][i]-W.reduce((s,x,k)=>k===top?s:s+x[i],0)/(K-1))});
 const terms=Object.entries(ev).filter(e=>e[1]>0).sort((a,b)=>b[1]-a[1]).slice(0,12);
 return{raw,kept,st,known,p,terms};
}
const $=id=>document.getElementById(id);
$("samples").innerHTML=Object.keys(SAMPLES).map(k=>`<button class="chip" data-k="${k}">${k}</button>`).join(" ");
$("samples").onclick=e=>{const k=e.target.dataset.k;if(k){$("t").value=SAMPLES[k];run()}};
$("stats").innerHTML=[[cats.length,"Categories"],[docs,"Training docs"],[V.size,"Vocabulary"],[(acc*100).toFixed(0)+"%","Train accuracy"]].map(a=>`<div class="stat"><b>${a[0]}</b><span class="mu">${a[1]}</span></div>`).join("");
function run(save=true){
 const text=$("t").value.trim();
 if(text.split(/\s+/).length<4){$("t").focus();$("t").placeholder="Please enter at least a short sentence…";return}
 const r=classify(text);
 if(!r.known.length){$("res").style.display="block";$("emo").textContent="🤔";$("cat").textContent="Not sure";$("conf").textContent="No recognisable terms found. Try a longer article.";$("bars").innerHTML="";return}
 $("res").style.display="block";$("res2").style.display="block";$("res3").style.display="block";
 const w=r.p[0];if(save)addH(text,w);$("emo").textContent=EMO[w.c];$("cat").textContent=w.c;
 $("conf").textContent="Confidence "+(w.p*100).toFixed(1)+"% · "+r.known.length+" informative terms";
 $("bars").innerHTML=r.p.map(x=>`<div class="bar"><span>${EMO[x.c]} ${x.c}</span><div class="track"><div class="fill" data-w="${(x.p*100).toFixed(1)}"></div></div><span>${(x.p*100).toFixed(1)}%</span></div>`).join("");
 requestAnimationFrame(()=>setTimeout(()=>document.querySelectorAll(".fill").forEach(f=>f.style.width=f.dataset.w+"%"),30));
 $("kws").innerHTML=r.terms.length?r.terms.map(t=>`<span class="kw">${t[0]} <b>+${t[1].toFixed(2)}</b></span>`).join(""):'<span class="mu">No strong terms.</span>';
 const cut=a=>a.slice(0,40).join(" ")+(a.length>40?" …":"");
 $("steps").innerHTML=[["1 · Tokenise",r.raw.length+" tokens",cut(r.raw)],["2 · Remove stop-words",r.kept.length+" remain",cut(r.kept)],["3 · Stem",r.st.length+" stems",cut(r.st)],["4 · TF-IDF + logistic regression",r.known.length+" in vocabulary","Sublinear TF × IDF, L2-normalised, scored by a softmax classifier."]].map(s=>`<div class="step"><h3>${s[0]}</h3><b>${s[1]}</b><div class="mu">${s[2]}</div></div>`).join("");
 $("res").scrollIntoView({behavior:"smooth",block:"start"});
}
const esc=s=>s.replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
let H=[];try{H=JSON.parse(localStorage.getItem("nl_h")||"[]")}catch(e){}
function save(){try{localStorage.setItem("nl_h",JSON.stringify(H))}catch(e){}}
function addH(t,w){H.unshift({c:w.c,p:(w.p*100).toFixed(0),s:t.slice(0,90),t:t.slice(0,3000),d:new Date().toLocaleDateString()});H=H.slice(0,15);save();drawH()}
function drawH(){$("hist").style.display=H.length?"block":"none";$("hl").innerHTML=H.map((h,i)=>`<div class="bar" style="grid-template-columns:40px 1fr 90px;cursor:pointer" data-i="${i}"><span style="font-size:26px">${EMO[h.c]}</span><span>${h.c} · ${h.p}%<br><span class="mu">${esc(h.s)}…</span></span><span class="mu">${h.d}</span></div>`).join("")}
$("hl").onclick=e=>{const d=e.target.closest("[data-i]");if(d){$("t").value=H[d.dataset.i].t;run(false)}};
$("clr").onclick=()=>{H=[];save();drawH()};
function load(file){const r=new FileReader();r.onload=()=>{let s=String(r.result);if(/\.html?$/i.test(file.name)){const d=new DOMParser().parseFromString(s,"text/html");d.querySelectorAll("script,style,nav,footer").forEach(x=>x.remove());s=(d.querySelector("article")||d.body).textContent.replace(/\s+/g," ")}$("t").value=s.slice(0,20000);run()};r.readAsText(file)}
const st=m=>$("st").textContent=m;
function fin(s){s=s.replace(/\s+/g," ").trim().slice(0,20000);if(!s)throw new Error("No text found");$("t").value=s;st("Imported "+s.split(" ").length+" words.");run()}
async function loadAny(file){
 const n=file.name.toLowerCase();
 try{
  if(/\.docx$/.test(n)){st("Reading Word document…");fin((await mammoth.extractRawText({arrayBuffer:await file.arrayBuffer()})).value)}
  else if(/\.pdf$/.test(n)||file.type==="application/pdf"){st("Reading PDF…");pdfjsLib.GlobalWorkerOptions.workerSrc="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";const pdf=await pdfjsLib.getDocument({data:await file.arrayBuffer()}).promise;let s="";for(let i=1;i<=Math.min(pdf.numPages,15);i++){const c=await(await pdf.getPage(i)).getTextContent();s+=c.items.map(x=>x.str).join(" ")+"\n"}
   if(s.trim().length<30)throw new Error("No selectable text in this PDF (it may be scanned). Export its pages as images and import those instead.");fin(s)}
  else if(file.type.startsWith("image/")){
   const sm=window.claude&&await claude.use("sample");
   if(!sm||!(await sm.limits()).images)throw new Error("Reading images is not available in this view.");
   st("Reading text from image…");
   const r=await sm("Transcribe all the text in this image exactly (it is a news article or screenshot). Output only the text, nothing else.",{images:[file],cache:false});fin(r.text)}
  else{st("");load(file)}
 }catch(e){st("Could not read file: "+(e.message||e))}
}
$("f").onchange=e=>{const f=e.target.files[0];if(f)loadAny(f);e.target.value=""};
$("t").ondragover=e=>e.preventDefault();
$("t").ondrop=e=>{e.preventDefault();e.dataTransfer.files[0]&&loadAny(e.dataTransfer.files[0])};
drawH();
$("go").onclick=()=>run();
